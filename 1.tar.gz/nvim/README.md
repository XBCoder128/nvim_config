# 前置依赖
```bash
# 图片转终端像素画
brew install chafa

brew install lua
brew install luarocks
brew install --cask font-maple-mono-nf-cn
brew install --cask font-maple-mono-nf-cn

# 图片+公式渲染
brew install imagemagick
brew install ghostscript
brew install tectonic

# 流程图渲染
npm install -g @mermaid-js/mermaid-cli

brew install lazygit
brew install ripgrep
brew install git-delta

# npm install -g tree-sitter-cli
```

# Dashboard
![example.gif](./image/example.gif)

> 公式渲染展示
$x + y = z^2$

$$\int_0^1 a\times dx \lambda$$
