vim.lsp.enable("pyright")

local function conda_shorter_name(filename)
   return filename:gsub("/opt/anaconda3/envs/", "󱔎  "):gsub("/opt/anaconda3", "  base"):gsub("/bin/python", "")
end

return {
	{
		"nvim-treesitter/nvim-treesitter",
		optional = true,
		opts = {
			ensure_installed = { "python" },
		},
		opts_extend = { "ensure_installed" },
	},
	{
		"mason-org/mason.nvim",
		optional = true,
		opts = {
			ensure_installed = {
				"ruff",
				"pyright",
			},
		},
		opts_extend = { "ensure_installed" },
	},

	{
		"stevearc/conform.nvim",
		optional = true,
		opts = {
			formatters_by_ft = {
				python = { "ruff_format" },
			},
		},
	},
	{
		"linux-cultist/venv-selector.nvim",
		dependencies = {
			"neovim/nvim-lspconfig",
			"folke/snacks.nvim",
			-- { "nvim-telescope/telescope.nvim", branch = "0.1.x", dependencies = { "nvim-lua/plenary.nvim" } },
		},
		-- 启动即加载，避免 Lazy :VenvSelect 桩删除后 setup 失败导致命令消失（E492）；不依赖先打开 .py
		lazy = false,
		keys = {
			{ "<leader>cv", "<cmd>VenvSelect<CR>", desc = "Select Python venv" },
		},
		config = function(_, opts)
			require("venv-selector").setup(opts)
		end,
		opts = { -- this can be an empty lua table - just showing below for clarity.
			options = {
				notify_user_on_venv_activation = true,
				picker = "snacks",
				-- on_telescope_result_callback = shorter_name
			},
			search = {
				anaconda_base = {
					command = "fd /bin/python$ /opt/anaconda3/bin -t l --full-path --color never -E pkgs",
					type = "anaconda",
					on_telescope_result_callback = conda_shorter_name
				},
				conda = {
					command = "fd /bin/python$ /opt/anaconda3/envs -t l --full-path --color never -E pkgs",
					type = "anaconda",
					on_telescope_result_callback = conda_shorter_name
				},
			},
		},
	},
}
